package fontys.util;

public class InvalidSessionException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidSessionException(String message) {
		super(message);
	}
}